-- Format for overwriting define values:
--
-- NDefines.NDiplomacy.DEMESNE_BASE_MAX_SIZE = 2.0

NDefines.NDiplomacy.DUKE_POWERFUL_VASSAL_COUNT = 0
NDefines.NDiplomacy.KING_POWERFUL_VASSAL_COUNT = 0
NDefines.NDiplomacy.EMPEROR_POWERFUL_VASSAL_COUNT = 0